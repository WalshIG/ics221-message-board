const React = require('react');
const Footer = () => {
    return (
        <p>
            &copy;2019 Gary Walsh 
        </p>
    );
}

module.exports = Footer     // allows this component to be used in a different file
