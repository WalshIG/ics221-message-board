const React = require('react');
const Header = () => {
    return (
        <h1>
            ICS 221 Message Board App Final Project
        </h1>
    );
}

module.exports = Header     // allows this component to be used in a different file
